import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import { useEffect, useState } from "react";
import { supabase } from "../services/supabase";

export default function MapView() {
  const [shelters, setShelters] = useState([]);

  const fetchData = async () => {
    let { data } = await supabase.from("shelters").select("*");
    setShelters(data || []);
  };

  useEffect(() => {
    fetchData();
    const subscription = supabase
      .channel("shelters-updates")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "shelters" },
        () => fetchData()
      )
      .subscribe();
    return () => supabase.removeChannel(subscription);
  }, []);

  return (
    <MapContainer
      center={[32.7157, -117.1611]}
      zoom={12}
      style={{ height: "100vh", width: "100%" }}
    >
      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
      {shelters.map((shelter) => (
        <Marker key={shelter.id} position={[shelter.lat, shelter.lng]}>
          <Popup>
            <strong>{shelter.name}</strong>
            <br />
            Beds: {shelter.available_beds}/{shelter.capacity}
            <br />
            Updated: {new Date(shelter.updated_at).toLocaleTimeString()}
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}
