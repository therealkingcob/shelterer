import MapView from "../components/MapView";

export default function Home() {
  return <MapView />;
}
